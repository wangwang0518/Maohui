import 'package:flutter/material.dart';
import 'cart_page.dart';
import 'filter_dialog.dart';
import 'product_detail_page.dart';
import '../models/product.dart';
import '../models/cart.dart';

class ProductListPage extends StatefulWidget {
  @override
  _ProductListPageState createState() => _ProductListPageState();
}

class _ProductListPageState extends State<ProductListPage> {
  List<Product> filteredProducts = productList;

  void applyFilter(String? brand, String? location) {
    setState(() {
      filteredProducts = productList.where((product) {
        final matchesBrand = brand == null || product.brand == brand;
        final matchesLocation = location == null || product.location == location;
        return matchesBrand && matchesLocation;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('商品列表'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => CartPage()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.filter_list),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                builder: (_) => FilterDialog(onApply: applyFilter),
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: filteredProducts.length,
        itemBuilder: (context, index) {
          final product = filteredProducts[index];
          return ListTile(
            leading: Image.asset(product.imageUrl, width: 50, height: 50),
            title: Text(product.name),
            subtitle: Text('价格: ¥${product.price.toStringAsFixed(2)}'),
            trailing: Text('销量: ${product.sales}'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ProductDetailPage(product: product),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
