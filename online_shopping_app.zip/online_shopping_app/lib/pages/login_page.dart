import 'package:flutter/material.dart';
import 'product_list_page.dart';

class LoginPage extends StatelessWidget {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('用户登录')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: usernameController,
              decoration: InputDecoration(labelText: '用户名'),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(labelText: '密码'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // 示例登录逻辑
                if (usernameController.text == 'wh' &&
                    passwordController.text == '123456') {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => ProductListPage()),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('用户名或密码错误')),
                  );
                }
              },
              child: Text('登录'),
            ),
          ],
        ),
      ),
    );
  }
}
