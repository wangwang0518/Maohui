import 'package:flutter/material.dart';

class PaymentMethodPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('选择支付方式')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              title: Text('信用卡'),
              leading: Icon(Icons.credit_card),
              onTap: () {
                _showPaymentConfirmation(context, '信用卡');
              },
            ),
            ListTile(
              title: Text('支付宝'),
              leading: Icon(Icons.payment),
              onTap: () {
                _showPaymentConfirmation(context, '支付宝');
              },
            ),
            ListTile(
              title: Text('微信支付'),
              leading: Icon(Icons.account_balance_wallet),
              onTap: () {
                _showPaymentConfirmation(context, '微信支付');
              },
            ),
            // 你可以根据需要添加其他支付方式
          ],
        ),
      ),
    );
  }

  // 弹出支付确认对话框
  void _showPaymentConfirmation(BuildContext context, String paymentMethod) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('支付确认'),
          content: Text('你选择了 $paymentMethod 作为支付方式'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);  // 关闭对话框
              },
              child: Text('关闭'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);  // 关闭对话框
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('支付成功！')),
                );
              },
              child: Text('确认支付'),
            ),
          ],
        );
      },
    );
  }
}
