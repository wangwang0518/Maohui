import 'package:flutter/material.dart';
import '../models/cart.dart';
import '../models/product.dart';
import 'payment_method_page.dart';  // 导入支付方式页面

class CartPage extends StatefulWidget {
  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  // 获取购物车商品列表
  List<Product> get cartItems => Cart.cartItems;

  // 计算总价
  double get totalPrice => cartItems.fold(0.0, (sum, item) => sum + item.price);

  // 移除商品
  void removeFromCart(Product product) {
    setState(() {
      Cart.removeFromCart(product);
    });
  }

  // 收货地址控制器
  final TextEditingController addressController = TextEditingController();

  @override
  void dispose() {
    addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('购物车')),
      body: Column(
        children: [
          Expanded(
            child: cartItems.isEmpty
                ? Center(child: Text('购物车为空'))
                : ListView.builder(
                    itemCount: cartItems.length,
                    itemBuilder: (context, index) {
                      final product = cartItems[index];
                      return ListTile(
                        leading: Image.asset(product.imageUrl, width: 50, height: 50),
                        title: Text(product.name),
                        subtitle: Text('¥${product.price.toStringAsFixed(2)}'),
                        trailing: IconButton(
                          icon: Icon(Icons.remove),
                          onPressed: () {
                            removeFromCart(product);  // 调用移除商品方法
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('${product.name} 已从购物车移除')),
                            );
                          },
                        ),
                      );
                    },
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: addressController,
                  decoration: InputDecoration(
                    labelText: '收货地址',
                    hintText: '请输入您的收货地址',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16.0),
                Text(
                  '总价: ¥${totalPrice.toStringAsFixed(2)}',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (addressController.text.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('请填写收货地址')),
                );
                return;
              }
              // 跳转到支付方式选择页面
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => PaymentMethodPage()),
              );
            },
            child: Text('结算'),
          ),
        ],
      ),
    );
  }
}



