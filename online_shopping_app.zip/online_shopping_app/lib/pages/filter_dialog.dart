import 'package:flutter/material.dart';

class FilterDialog extends StatefulWidget {
  final Function(String?, String?) onApply;

  FilterDialog({required this.onApply});

  @override
  _FilterDialogState createState() => _FilterDialogState();
}

class _FilterDialogState extends State<FilterDialog> {
  String? selectedBrand;
  String? selectedLocation;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CheckboxListTile(
            title: Text('品牌A'),
            value: selectedBrand == '品牌A',
            onChanged: (selected) {
              setState(() {
                selectedBrand = selected! ? '品牌A' : null;
              });
            },
          ),
          CheckboxListTile(
            title: Text('品牌B'),
            value: selectedBrand == '品牌B',
            onChanged: (selected) {
              setState(() {
                selectedBrand = selected! ? '品牌B' : null;
              });
            },
          ),
          Divider(),
          CheckboxListTile(
            title: Text('发货地: 上海'),
            value: selectedLocation == '上海',
            onChanged: (selected) {
              setState(() {
                selectedLocation = selected! ? '上海' : null;
              });
            },
          ),
          CheckboxListTile(
            title: Text('发货地: 北京'),
            value: selectedLocation == '北京',
            onChanged: (selected) {
              setState(() {
                selectedLocation = selected! ? '北京' : null;
              });
            },
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              widget.onApply(selectedBrand, selectedLocation);
              Navigator.pop(context);
            },
            child: Text('应用筛选'),
          ),
        ],
      ),
    );
  }
}
