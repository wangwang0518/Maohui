import '../models/product.dart';

final List<Product> productList = [
  Product(
    imageUrl: 'assets/images/product1.jpg',
    name: 'fufu玩偶',
    price: 29.99,
    sales: 1000,
    brand: '品牌A',
    location: '上海',
  ),
  Product(
    imageUrl: 'assets/images/product2.jpg',
    name: '苹果手机',
    price: 799.99,
    sales: 2500,
    brand: '品牌A',
    location: '北京',
  ),
  Product(
    imageUrl: 'assets/images/product3.jpg',
    name: '卫衣简约',
    price: 199.99,
    sales: 500,
    brand: '品牌B',
    location: '北京',
  ),
  Product(
    imageUrl: 'assets/images/product4.jpg',
    name: '卫衣可爱',
    price: 99.99,
    sales: 200,
    brand: '品牌B',
    location: '上海',
  )
  // 添加更多商品
];

